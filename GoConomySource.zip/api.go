package main

import "sync"

type EconomyAPI interface {
    GetBalance(player string) int
    AddMoney(player string, amount int)
    Pay(from string, to string, amount int) bool
}

type economyAPIImpl struct {
    balances map[string]int
    lock     *sync.RWMutex
}

func (e *economyAPIImpl) GetBalance(player string) int {
    e.lock.RLock()
    defer e.lock.RUnlock()
    return e.balances[player]
}

func (e *economyAPIImpl) AddMoney(player string, amount int) {
    e.lock.Lock()
    e.balances[player] += amount
    e.lock.Unlock()
}

func (e *economyAPIImpl) Pay(from, to string, amount int) bool {
    e.lock.Lock()
    defer e.lock.Unlock()

    if e.balances[from] < amount {
        return false
    }

    e.balances[from] -= amount
    e.balances[to] += amount
    return true
}