module economyplugin

go 1.21

require github.com/GoMint/gomint v1.0.0