package main

import (
    "fmt"
    "strconv"
    "sync"

    "github.com/GoMint/gomint/plugin"
    "github.com/GoMint/gomint/world"
)

type EconomyPlugin struct {
    api *economyAPIImpl
}

func (ep *EconomyPlugin) OnEnable() {
    ep.api = &economyAPIImpl{
        balances: make(map[string]int),
        lock:     &sync.RWMutex{},
    }

    plugin.LogInfo("EconomyPlugin запущен!")

    plugin.Set("economy:api", ep.api)

    // Плейсхолдер %деньги%
    plugin.Placeholders().Register("деньги", func(player world.Player) string {
        return strconv.Itoa(ep.api.GetBalance(player.Name()))
    })

    // При входе
    plugin.Events().PlayerJoin(func(event plugin.PlayerJoinEvent) {
        name := event.Player().Name()
        if ep.api.GetBalance(name) == 0 {
            ep.api.AddMoney(name, 100)
        }

        event.Player().SendMessage(fmt.Sprintf("§aДобро пожаловать! Ваш баланс: §6%d §aмонет", ep.api.GetBalance(name)))
    })

    // /баланс
    plugin.Commands().Register("баланс", func(ctx plugin.CommandContext) {
        player := ctx.Sender().(world.Player)
        bal := ep.api.GetBalance(player.Name())
        player.SendMessage(fmt.Sprintf("§eВаш баланс: §6%d монет", bal))
    })

    // /деньги <сумма>
    plugin.Commands().Register("деньги", func(ctx plugin.CommandContext) {
        player := ctx.Sender().(world.Player)

        if len(ctx.Args()) != 1 {
            player.SendMessage("§cИспользование: /деньги <сумма>")
            return
        }

        amount, err := strconv.Atoi(ctx.Args()[0])
        if err != nil || amount <= 0 {
            player.SendMessage("§cНеверная сумма.")
            return
        }

        ep.api.AddMoney(player.Name(), amount)
        player.SendMessage(fmt.Sprintf("§aВы получили §6%d §aмонет", amount))
    })

    // /передать <игрок> <сумма>
    plugin.Commands().Register("передать", func(ctx plugin.CommandContext) {
        sender := ctx.Sender().(world.Player)

        if len(ctx.Args()) != 2 {
            sender.SendMessage("§cИспользование: /передать <игрок> <сумма>")
            return
        }

        target := ctx.Args()[0]
        amount, err := strconv.Atoi(ctx.Args()[1])
        if err != nil || amount <= 0 {
            sender.SendMessage("§cНеверная сумма.")
            return
        }

        if !ep.api.Pay(sender.Name(), target, amount) {
            sender.SendMessage("§cНедостаточно монет!")
            return
        }

        sender.SendMessage(fmt.Sprintf("§aВы отправили §6%d §aмонет игроку %s", amount, target))
    })
}

func (ep *EconomyPlugin) OnDisable() {
    plugin.LogInfo("EconomyPlugin выключен.")
}
